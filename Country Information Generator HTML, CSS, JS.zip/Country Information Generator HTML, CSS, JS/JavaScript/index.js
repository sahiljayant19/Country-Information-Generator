// Variables..........................
let countryName = null;
let response;
let whiteBox = document.querySelector(".container");
let p = document.createElement("p");
let h = document.createElement("h1");
let whiteBox2 = document.querySelector(".box2");
let wm = document.querySelector(".info");
let theme_text = document.querySelector(".text");
let theme_box = document.querySelector(".theme-box");
let nav_text = document.querySelectorAll(".cl-wh");
let nav = document.querySelector(".navbar");
let searchBox = document.querySelector(".searchBox");
let searchButton = document.querySelector(".searchButton");
let inputBox = document.getElementById("searchInput");
let template_text = document.querySelector(".template-text");
let nav_textArr = Array.from(nav_text);
let theme = document.getElementById("theme");
// inputBox.style.setProperty('--placeholder-color', 'grey');
// ----------------------------------------------------------

const getCountryDetails = async () => {
    let url = `https://restcountries.com/v3.1/name/${countryName}`;
    let response = await fetch(url);
    response = await response.json();
    return response;
}

function getCountry() {
    let searchBox = document.getElementById("searchInput");
    countryName = searchBox.value;
}

const showCountryDetails = async () => {  // EVENT LISTENER-------------------------------------------
    searchBox.value = null
    response = await getCountryDetails();
    if (response.status == 404) {
        whiteBox.innerHTML = ""
        h.innerHTML = "404";
        p.innerHTML = `Country '${countryName}' Not Found <br> The resource requested could not be found on this server!`;
        whiteBox.append(h, p);
    }
    p.setAttribute("class", "country-details");
    let country = response[0];
    let currency = Object.values(country.currencies)[0];
    p.innerHTML = `Country's Name: ${country.name.common} <br>
                   Country's Alternative Names: ${country.altSpellings[0]}, ${country.altSpellings[1]} <br>
                   Country's Area: ${country.area} <br>
                   Country's Borders: ${country.borders} <br>
                   Country's Capital: ${country.capital} <br>
                   Country's Road Side: ${country.car.side} <br>
                   Country's Currency Name: ${currency.name} <br>
                   Country's Currency Symbol: ${currency.symbol} <br>
                   Country's Population: ${country.population} <br>
                   Country's Start Of Week: ${country.startOfWeek} <br>
                   Country's TimeZone: ${country.timezones[0]} <br>
                   Country's continents: ${country.continents} <br>`
    whiteBox.innerHTML = "";
    whiteBox.appendChild(p);
}

function eventListeners() {
    searchBox.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            event.preventDefault();
            showCountryDetails();
        }
    })

    searchButton.addEventListener('click', showCountryDetails); // Search button EventListener..........

    theme.addEventListener('click', () => { // Theme button EventListener..........
        if (theme_text.innerHTML == "Apply Dark Theme") {
            theme_box.style.background = "rgb(113, 119, 131)";
            theme_text.style.color = "white";
            theme_text.innerHTML = "Apply Light Theme";
            document.body.style.background = "rgb(40, 39, 39)"; // All dark theme properties.
            document.body.style.transition = "background 0.3s ease-in-out";
            whiteBox.style.background = "rgb(39, 39, 39)";
            whiteBox2.style.background = "rgb(39, 39, 39)";
            p.style.color = "white";
            h.style.color = "white";
            wm.style.color = "white";
            searchBox.style.color = "white";
            template_text.style.color = "white";
            searchBox.style.background = "rgb(81, 81, 81)";
            searchBox.style.borderColor = "rgba(0, 149, 182, 0.824) ";
            searchButton.style.background = "rgb(81, 81, 81)";
            searchButton.style.borderColor = "rgba(0, 149, 182, 0.824) ";
            searchButton.firstElementChild.style.color = "white";
            nav.style.background = "rgb(54, 53, 53)";
            nav.style.transition = "background 0.4s ease-in-out";
            nav_textArr.forEach((element) => {
                element.style.color = "white";
            });
            inputBox.style.setProperty('--placeholder-color', 'rgba(233, 233, 233, 0.462)');
        }
        else {
            theme_text.style.color = "black";
            theme_text.innerHTML = "Apply Dark Theme";
            theme_box.style.background = "white";
            document.body.style.background = "rgb(180, 180, 180)"; // All light theme properties.
            whiteBox.style.background = "white";
            whiteBox2.style.background = "white";
            p.style.color = "rgb(64, 0, 93)";
            h.style.color = "rgb(57, 55, 55)";
            wm.style.color = "black";
            searchBox.style.color = "black";
            template_text.style.color = "rgb(64, 0, 93)";
            searchBox.style.background = "white";
            searchBox.style.borderColor = "rgb(100, 0, 207)";
            searchButton.style.background = "white";
            searchButton.style.borderColor = "rgb(100, 0, 207)";
            searchButton.firstElementChild.style.color = "black";
            nav.style.background = "rgb(230, 230, 230)";
            nav_textArr.forEach((element) => {
                element.style.color = "black";
            });
            inputBox.style.setProperty('--placeholder-color', 'grey');
        }
    });
}
eventListeners()