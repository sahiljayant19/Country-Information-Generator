let theme_text = document.querySelector(".text");
let theme_box = document.querySelector(".about-theme-box");
let nav_text = document.querySelectorAll(".cl-wh");
let nav = document.querySelector(".navbar");
let nav_textArr = Array.from(nav_text);
let theme = document.getElementById("theme");
let textarea = document.getElementById("fbk")
let h = document.querySelector(".container").firstElementChild
let sumbit = document.querySelector(".submit")

setInterval(() => {
    textarea.classList.toggle('glow')
}, 500);

theme.addEventListener('click', () => {
    if (theme_text.innerHTML == "Apply Dark Theme") {
        sumbit.style.background = "rgb(40, 39, 39)"
        sumbit.style.color = "white"
        h.style.color = "white"
        document.body.style.background = "rgb(40, 39, 39)"
        textarea.style.background = "rgb(40, 39, 39)"
        textarea.style.color = "white"
        theme_box.style.background = "rgb(113, 119, 131)";
        theme_text.style.color = "white";
        theme_text.innerHTML = "Apply Light Theme";
        theme_box.style.outline = "none";
        nav.style.background = "rgb(54, 53, 53)";
        nav_textArr.forEach((element) => {
            element.style.color = "white";
        });
        textarea.style.background = "rgb(45, 45, 45)"
    }
    else {
        sumbit.style.background = "white"
        sumbit.style.color = "black"
        h.style.color = "black"
        document.body.style.background = "rgb(205, 205,  205)"
        textarea.style.background = "white"
        textarea.style.color = "black"
        theme_text.style.color = "black";
        theme_text.innerHTML = "Apply Dark Theme";
        theme_box.style.background = "white";
        theme_box.style.outline = "1px solid purple"
        nav.style.background = "rgb(230, 230, 230)";
        nav_textArr.forEach((element) => {
            element.style.color = "black";
        });
    }
})