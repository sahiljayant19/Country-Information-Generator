let theme_text = document.querySelector(".text");
let theme_box = document.querySelector(".about-theme-box");
let nav_text = document.querySelectorAll(".cl-wh");
let nav = document.querySelector(".navbar");
let nav_textArr = Array.from(nav_text);
let theme = document.getElementById("theme");
let about_section = document.querySelector(".about-section")
let p = document.querySelectorAll(".wh-p")
let h2 = about_section.firstElementChild
let h3 = document.getElementsByTagName("h3")
let pArr = Array.from(p)
let join = document.querySelectorAll(".join")
let h3Arr = Array.from(h3)
let joinArr = Array.from(join)

theme.addEventListener('click', () => { // Theme button EventListener..........
    console.log("clicked");
    if (theme_text.innerHTML == "Apply Dark Theme") {
        theme_box.style.background = "rgb(113, 119, 131)";
        theme_text.style.color = "white";
        h2.style.color = "white"
        theme_text.innerHTML = "Apply Light Theme";
        theme_box.style.outline = "none";
        about_section.style.background = "rgb(40, 39, 39)"
        nav.style.background = "rgb(54, 53, 53)";
        nav_textArr.forEach((element) => {
            element.style.color = "white";
        });
        pArr.forEach((element) => {
            element.style.color = "white"
        });
        h3Arr.forEach((element) => {
            element.style.color = "white"
        });
        joinArr.forEach((element) => {
            element.style.color = "white"
        });
    }
    else {
        theme_text.style.color = "black";
        theme_text.innerHTML = "Apply Dark Theme";
        h2.style.color = "#333"
        about_section.style.background = "#f9f9f9"
        theme_box.style.background = "white";
        theme_box.style.outline = "1px solid purple"
        nav.style.background = "rgb(230, 230, 230)";
        nav_textArr.forEach((element) => {
            element.style.color = "black";
        });
        pArr.forEach((element) => {
            element.style.color = "black"
        });
        h3Arr.forEach((element) => {
            element.style.color = "black"
        });
        joinArr.forEach((element) => {
            element.style.color = "black"
        });
    }
});